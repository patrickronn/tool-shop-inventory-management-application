import client.controller.clientcontroller.ClientInitializer;

public class ClientMain {
    public static void main(String[] args) {
        ClientInitializer.initialize();
    }
}