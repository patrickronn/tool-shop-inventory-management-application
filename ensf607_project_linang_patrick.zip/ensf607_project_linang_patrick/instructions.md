# Instructions for ENSF Final Project
Submitted by: Patrick Linang

## Files
- For pre-project exercise, please see `preproject_linang_patrick` directory
- For tool shop server project files, please see `tool-shop-server` directory
- For tool shop client project files, please see `tool-shop-client` directory
    - Please note that I developed my GUIs using IntelliJ GUI Designer. If
    you experience errors with client view/GUIs please add a dependency to the file `forms_rt.jar`
    (a similar fashion to how you add the JDBC jar file)
    - This file is located in `tool-shop-client/lib/forms_rt.jar`